

<?php $__env->startSection('content'); ?>

<div class="col-sm-12">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.css">

</div>
<!-- main content start-->
<div id="page-wrapper" style="min-height: 918px;">
   <div class="main-page">
      <div class="tables">
         <h2 class="title1">Tables</h2>
           <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
         <div class="bs-example widget-shadow" data-example-id="hoverable-table">
            <h4>User List:</h4>
            <a class="btn btn-success" style="float: right;" href="<?php echo e(url('addregister')); ?>">Add User</a>
            <table class="table table-hover" id="myTable">
               <thead>
                  <tr>
                     <th>#</th>
                     <th>Users Name</th>
                      <th>email</th>
                      <th>created</th>
                      <th>verified</th>
                     <th>Edit</th>
                     <th>Delete</th>
                  </tr>
               </thead>
               <?php
                  $no=1;
                   ?>
                  
                 
               <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                  <tr>
                     <th scope="row"><?php echo e($no++); ?></th>
                     <td><?php echo e($key->name); ?></td>
                    <td><?php echo e($key->email); ?></td>
                    <td><?php echo e($key->created_at); ?></td>
                    <td><?php if($key->email_verified_at): ?>
                      <?php echo e($key->email_verified_at); ?></td>
                        <?php else: ?>
                        <a href="<?php echo e(url('/verified/user')); ?>/<?php echo e($key->id); ?>" class="btn btn-warning">verified</a>
                          <?php endif; ?>
                     <td><a href="<?php echo e(url('/edit/user')); ?>/<?php echo e($key->id); ?>" class="btn btn-primary">Edit</a></td>
                     <td><a onclick="myFunction(<?php echo $key->id;?>)"  class="btn btn-danger">Delete</a></td>
                  </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
            <div align="right">
             <a class="btn btn-success" href="<?php echo e(route('file-export')); ?>">Excel  data</a>
             <a class="btn btn-primary" href="<?php echo e(url('file-import-export')); ?>">Excel Insert data</a>

             </div>
         </div>
      </div>
   </div>
</div>
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.js"></script>

<script>
  $(document).ready( function () {
    $('#myTable').DataTable();
} );
</script>

<script>
   function myFunction($id) {
     var txt;
     var r = confirm("Press a button!");
     if (r == true) {
       window.location.href = "/Delete/user/"+$id;
     } else {
       txt = "You pressed Cancel!";
     }
     document.getElementById("demo").innerHTML = txt;
   }
</script>           


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/userlist.blade.php ENDPATH**/ ?>