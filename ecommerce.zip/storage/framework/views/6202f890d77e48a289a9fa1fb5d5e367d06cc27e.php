
 <?php $__env->startSection('content'); ?>
 <a href="/productilist" style="float: right;" class="btn btn-primary">Bake</a>
<div class="container">
	<div class="form-group"><label><b>Product ID :</b></label> <label><?php echo e($pro[0]->product_id); ?></label></div>


	<div class="form-group"><label><b>Model NO :</b></label> <label><?php echo e($pro[0]->modelno); ?></label></div>


	<div class="form-group"><label><b>Category ID :</b></label> <label><?php echo e($pro[0]->cat_id); ?></label></div>


	<div class="form-group"><label><b>Product Name :</b></label> <label><?php echo e($pro[0]->productname); ?></label></div>


	<div class="form-group"><label><b>Shot Description :</b></label> <label><?php echo e($pro[0]->shot_description); ?></label></div>


<div class="form-group"><label><b>Description  :</b></label> <label><?php echo e($pro[0]->description); ?></label></div>


	<div class="form-group"><label><b>Image :</b></label> <img style="max-height: 40vh; max-width: 40vh; float: right;" src="/uploads/productimage/<?php echo e($pro[0]->image); ?>"></div>


	<div class="form-group"><label><b>Product price :</b></label> <label><?php echo e($pro[0]->price); ?></label></div>


	<div class="form-group"><label><b>Product discount :</b></label> <label><?php echo e($pro[0]->discount); ?></label></div>


	<div class="form-group"><label><b>Product Discount price :</b></label> <label><?php echo e($pro[0]->discount_price); ?></label></div>


	<div class="form-group"><label><b>Product Sell Price :</b></label> <label><?php echo e($pro[0]->sell_price); ?></label></div>

	
	<div class="form-group"><label><b>Mote Image</b></label><br><br>
		<?php foreach ($pro as  $value) {?>
		<img style=" max-width: 30vh; max-height: 30vh;" src="/uploads/allimg/<?php echo e($value->imgname); ?>">
		<?php
	} ?>
	 </div>
</div>



 <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/show.blade.php ENDPATH**/ ?>