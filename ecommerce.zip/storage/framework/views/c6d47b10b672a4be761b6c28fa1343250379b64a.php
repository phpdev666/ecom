 

<?php $__env->startSection('content'); ?>

<!-- breadcrumbs -->
	<div class="breadcrumbs">
		<div class="container">
			<ol class="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
				<li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span>Home</a></li>
				<li class="active">Products</li>
			</ol>
		</div>
	</div>
<!-- //breadcrumbs -->
<!--- products --->
	<div class="products">
		<div class="container-fluid">
			<div class="col-md-2 products-left">
				<div class="categories">
					<h2>Categories</h2>
					<ul class="cate">
						<?php $__currentLoopData = $cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li><a href="<?php echo e(url('/products/select',$cats->cat_id )); ?>"><i class="fa fa-arrow-right" aria-hidden="true"></i><?php echo e($cats->name); ?></a></li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						
					</ul>
				</div>																																												
			</div>
			<div class="col-md-9 products-right">
				

				<?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<div class="agile_top_brands_grids">
								<div class="col-md-3 top_brand_left"  style="margin-bottom: 10px;">
									<div class="hover14 column" >
										<div class="agile_top_brand_left_grid" >
											
											<div class="agile_top_brand_left_grid1">
												<figure>
													<div class="snipcart-item block" >
														<div class="snipcart-thumb">
															<a href="<?php echo e(url('products',$pro->product_id)); ?>"><img style="  min-height: 19vh;  max-width: 50vh;
    max-height: 19vh;" src="<?php echo e(url('uploads/productimage/',$pro->image)); ?>" /></a>		
															<p><?php echo e(substr($pro->productname, 0,25)); ?>..</p>
															
															<h4><?php echo e($pro->sell_price); ?> <span><?php echo e($pro->price); ?></span></h4>
														</div>
														<div class="snipcart-details top_brand_home_details">
													<?php if($pro->status=='deactivate'): ?>
													<h3 style="font-size: 31px; color: red;">Out of stock</h3>
													<?php else: ?>
													<form action="<?php echo e(url('addcart',$pro->product_id )); ?>" method="post">
														<?php echo csrf_field(); ?>
														<fieldset>
															<input type="hidden" name="path" value="<?php echo e(url('products/select',$pro->cat_id)); ?>">
															<input type="hidden" name="id" value="<?php echo e($pro->product_id); ?>">
															<input type="submit" name="submit" value="Add to cart" class="button">
														</fieldset>
													</form>
													<?php endif; ?>								
													

														</div>
													</div>
												</figure>
											</div>
										</div>
									</div>
								</div></div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					
						<div class="clearfix"> </div>
				</div>
				
			<div class="clearfix"> </div>
			<div align="center"><?php echo e($get->links()); ?></div>
	</div>
<!--- products --->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/products.blade.php ENDPATH**/ ?>