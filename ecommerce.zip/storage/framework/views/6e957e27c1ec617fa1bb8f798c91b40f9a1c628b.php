<?php echo e($slot); ?>

<?php /**PATH C:\wamp64\www\ecommerce\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>