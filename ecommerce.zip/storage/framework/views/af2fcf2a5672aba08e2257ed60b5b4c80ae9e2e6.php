 <?php $__env->startSection('content'); ?>


<form method="post" action="<?php echo e(url('checkoutinsert')); ?>"><?php echo csrf_field(); ?>
<div class="row">
    <div class="col-md-8" style="padding: 15vh;">
    	<div class="form-group" style="display: flex;">
	    	<input type="text" name="fist_name" class="form-control" value="<?php echo e(old('fist_name')); ?>" placeholder="Fist Name" style="  margin: 0 15px 0 0;"> 
	    	<input type="text" name="last_name" class="form-control" value="<?php echo e(old('last_name')); ?>" placeholder="Las Name">
    	</div>
    	<div style="color: #d25555;">
    	  <?php $__errorArgs = ['fist_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong style="float: right;"><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
    	<div class="form-group">
	    	<input type="number" name="number"  value="<?php echo e(old('number')); ?>"  class="form-control" placeholder="content Number">
    	</div>
    	<div style="color: #d25555;">
    	  <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  </div>
    	<div class="form-group">
	    	<input type="email" name="email"  value="<?php echo e(old('email')); ?>"   class="form-control" placeholder="Email">
    	</div>
    	<div style="color: #d25555;">
    	  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  </div>
    	<div class="form-group">
	    	<textarea name="address" class="form-control" placeholder="Address"><?php echo e(old('email')); ?> </textarea>
    	</div>
    	<div style="color: #d25555;">
    	  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  </div>
    	<div class="form-group" style="display: flex;">
			<select name="country" class="form-control">
				<option hidden value="">select country</option>
				<option>United States</option>
				<option>Russia</option>
				<option>China</option>
				<option>india</option>
				<option>Australia</option>
				<option>Argentina</option>
				<option>Kazakhstan</option>
				<option>Sudan</option>				
			</select>
			<select name="state" class="form-control" style=" margin: 0 0 0 15px;">
				<option hidden value="">select  state</option>
				<option>Sakha Republic</option>
				<option>Gujrat</option>
				<option>State of Western Australia</option>
				<option>Krasnoyarsk Krai</option>
				<option>Greenland</option>
							
			</select>	
    	
    	 </div>
    	 <div style="color: #d25555;">
    	  <?php $__errorArgs = ['country'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  <?php $__errorArgs = ['state'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong style="float: right;"><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
    	 <div class="form-group" style="display: flex;">
			
			<select name="City" class="form-control" style=" margin: 0 15px 0 0;">
				<option hidden value="" >state  City </option>
				<option>Surat</option>
				<option>Jerusalem</option>
				<option>Cape Town</option>
				<option>Tel Aviv</option>
				<option>Marrakesh, Morocco</option>
				<option>Kyoto</option>
		
			</select>	    
				<input type="number" name="pincode" value="<?php echo e(old('pincode')); ?>"   class="form-control" placeholder="Pin code">
    	 </div>
    	  <div style="color: #d25555;">
    	  <?php $__errorArgs = ['City'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    	  <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="invalid-feedback" role="alert"><strong style="float: right;"><?php echo e($message); ?></strong></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
		</div>
    	 <div class="form-group" >
    	 	<button type="submit" class="btn btn-primary" style=" font-size: 20px; float: right;">submit</button>
    	 </div>
   	</div>
    <div class="col-md-4" style="padding: 60px;">
        <table id="tblid" class="table table-hover">
            <thead>
                <tr>
                    <th>SL No.</th>
                    <th>Product</th>
                    <th>Quality</th>

                    <th>Price</th>
                </tr>
            </thead>
            <label style="display: none;"><?php echo e($no=1); ?></label>

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e(substr($key['name'],0,30)); ?>..</td>
                <td><?php echo e($key['qty']); ?></td>
                <td><?php echo e($key['qty']*$key['price']); ?></td>
                <input type="hidden" name="pro[<?php echo e($no-1); ?>][id]" value="<?php echo e($key['pid']); ?>" />
                <input type="hidden" name="pro[<?php echo e($no-1); ?>][qty]" value="<?php echo e($key['qty']); ?>" />
                <input type="hidden" name="pro[<?php echo e($no-1); ?>][price]" value="<?php echo e($key['price']); ?>" />
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
</div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/checkout.blade.php ENDPATH**/ ?>