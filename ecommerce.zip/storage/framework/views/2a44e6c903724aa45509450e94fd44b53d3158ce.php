 

<?php $__env->startSection('content'); ?>


<div id="page-wrapper">
   <div class="main-page">
      <div class="forms">
         <h2 class="title1"> Settings</h2>
         <div class="form-grids row widget-shadow" data-example-id="basic-forms">
            <div class="form-title">
                      <?php if($errors->any()): ?>
    <div >
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style=" display: block; " class="alert alert-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
               <h4>Settings:</h4>
            </div>
            <div class="form-body">
               <form method="post" action="settings">
   <?php echo csrf_field(); ?>
                   <input type="hidden" name="id" value="<?php echo e($get[0]->settings_id); ?>">

                  
                  <div class="form-group">
                   <label for="">company Name</label>
                    <input type="text" name="company_name" value="<?php echo e($get[0]->company_name); ?>" class="form-control" id="company Name"  placeholder="company Name">
                     </div>

                     <div class="form-group">
                   <label for="">company Email</label>
                    <input type="text" name="Email" value="<?php echo e($get[0]->Email); ?>" class="form-control" id="company Email"  placeholder="company Email">
                     </div>
                 
                  <div class="form-group">
                   <label for="">Mobile Number</label>
                    <input type="text" name="mobile_number" value="<?php echo e($get[0]->mobile_number); ?>" class="form-control" id="company Email"  placeholder="company Mobilen Number">
                     </div>

                   <div class="form-group">
                   <label >Address</label>
                   <textarea name="address"  placeholder="Address" style=" width: 100%; min-height: 10vh;"><?php echo e($get[0]->address); ?></textarea>
                     </div>
                      <div class="form-group">
                   <label >Map URL</label>
                   <textarea name="mapurl" id="map" placeholder="mapurl" style=" width: 100%; min-height: 10vh;"><?php echo e($get[0]->mapurl); ?></textarea>
                     </div>
                    
                    <div class="form-group">
                   <label><b>Terms Conditions</b></label>
                   <textarea name="terms_conditions" id="temp" placeholder="Address" style=" width: 100%; "><?php echo e($get[0]->terms_conditions); ?></textarea>
                     </div>

                  <button type="submit" class="btn btn-success">Submit</button> 
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<script src="https://cdn.ckeditor.com/[version.number]/[distribution]/ckeditor.js"></script>
 <script>
                        CKEDITOR.replace( 'temp' );
 </script>
  <script>
                        CKEDITOR.replace( 'map' );
 </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/setingspahe.blade.php ENDPATH**/ ?>