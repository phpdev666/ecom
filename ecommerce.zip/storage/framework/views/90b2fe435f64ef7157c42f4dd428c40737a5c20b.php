<h1>test</h1>
<p><?php echo e($name); ?></p><?php /**PATH C:\wamp64\www\ecommerce\resources\views/mail.blade.php ENDPATH**/ ?>