 

<?php $__env->startSection('content'); ?>


<div id="page-wrapper">
   <div class="main-page">
      <div class="forms">
         <h2 class="title1">Forms</h2>
         <div class="form-grids row widget-shadow" data-example-id="basic-forms">
            <div class="form-title">
                      <?php if($errors->any()): ?>
    <div >
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="display: block;" class="alert alert-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
               <h4>Add Testi Monials :</h4>
            </div>
            <div class="form-body">
               <form method="post">
   <?php echo csrf_field(); ?>
                   

                  
                  <div class="form-group">
                   <label for="exampleInputPassword1">title</label> 
                   <input type="text" name="title" class="form-control" id="Category Name"  placeholder="Title">
                    </div>

                  <div class="form-group">
                   <label for="exampleInputPassword1">Description</label> 
                   <textarea name="description" style="  min-height: 20vh; width: 100%; border: 1px solid #ccc;" placeholder="Description"></textarea>
                    </div>
                 
                 
                 
                  <button type="submit" class="btn btn-success">Submit</button> 
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/testmoduls.blade.php ENDPATH**/ ?>