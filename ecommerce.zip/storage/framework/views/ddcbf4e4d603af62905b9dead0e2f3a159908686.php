

<?php $__env->startSection('content'); ?>
<div class="col-sm-12">

  
</div>
<!-- main content start-->
<div id="page-wrapper" style="min-height: 918px;">
   <div class="main-page">
      <div class="tables">
         <h2 class="title1">Tables</h2>
         <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
         <div class="bs-example widget-shadow" data-example-id="hoverable-table">
            <h4>slider List:</h4>
            <a class="btn btn-success" style="float: right;" href="/slider/add">Add slider</a>
            <table class="table table-hover" id="tbid">
               <thead>
                  <tr>
                     <th>#</th>
                     <th>slider Name</th>
                     <th>Image</th>
                     <th>Edit</th>
                     <th>Delete</th>
                  </tr>
               </thead>
               <?php
                  $no=1;
                  
                  foreach ($data as $key ) {
                  
                  ?>
               <tbody>
                  <tr>
                     <th scope="row"><?php echo e($no++); ?></th>
                     <td><?php echo e($key->name); ?></td>
                    <td><img class="img-responsive" style="   max-width: 25vh;max-height: 25vh;" src="<?php echo e(url('uploads/slider/')); ?>/<?php echo e($key->image); ?>"></td>
                     <td><a href="/edit/slider/<?php echo e($key->slider_id); ?>" class="btn btn-primary">Edit</a></td>
                     <td><a onclick="myFunction(<?php echo $key->slider_id ;?>)"  class="btn btn-danger">Delete</a></td>
                  </tr>
                  <?php
                     }
                         ?>
               </tbody>
            </table>
         </div>
      </div>
   </div>
</div>
<script>
   function myFunction($id) {
     var txt;
     var r = confirm("Press a button!");
     if (r == true) {
       window.location.href = "/Delete/slider/"+$id;
     } else {
       txt = "You pressed Cancel!";
     }
     document.getElementById("demo").innerHTML = txt;
   }
</script>           


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/sliderdata.blade.php ENDPATH**/ ?>