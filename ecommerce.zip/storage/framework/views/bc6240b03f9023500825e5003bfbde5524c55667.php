 

<?php $__env->startSection('content'); ?>




<div id="page-wrapper">
   <div class="main-page">
      <div class="forms">
         <h2 class="title1">Forms</h2>
         <div class="form-grids row widget-shadow" data-example-id="basic-forms">
            <div class="form-title">
               <h4>Edit Category:</h4>
            </div>
            <div class="form-body">
               <form method="post" action="<?php echo e(url('/edit/cat/$get[0]->cat_id')); ?>">
   <?php echo csrf_field(); ?>
                 <input type="hidden" name="cat_id" value="<?php echo e($get[0]->cat_id); ?>">  

                  
                  <div class="form-group"> <label for="exampleInputPassword1">Category Name</label> <input type="text" name="name" value="<?php echo e($get[0]->name); ?>" class="form-control" id="Category Name"  placeholder="Category Name"> </div>
                 
                 
                 
                  <button type="submit" class="btn btn-success">Submit</button> 
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/editdata.blade.php ENDPATH**/ ?>