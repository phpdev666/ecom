

<?php $__env->startSection('content'); ?>
<div class="col-sm-12">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">

  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div>
  <?php endif; ?>
</div>
<!-- main content start-->
<div id="page-wrapper" style="min-height: 918px;">
   <div class="main-page">
      <div class="tables">
         <h2 class="title1">Tables</h2>
         <div class="bs-example widget-shadow" data-example-id="hoverable-table">
            <h4>Category List:</h4>
            <a class="btn btn-success" style="float: right;" href="/addproduct">Add Category</a>
            <table class="table table-hover" id="tbl">
               <thead>
                  <tr>
                     <th>#</th>
                     <th>Model No</th>
                     <th>Category Name</th>
                     <th>Product Name</th>
                     <th>shot Description</th>
                     <th>Description</th>
                     <th>image</th>
                     <th>Price</th>
                     <th>Discount</th>
                     <th>discount price</th>
                     <th>sell price</th>
                     <th>active/deactivate</th>
                     <th>PDF</th>
                     <th>Show</th>
                     <th>Edit</th>
                     <th>Delete</th>
                  </tr>
               </thead>
              
               <label style="display: none;">  <?php echo e($no=1); ?></label>
                  
                  
                 
               <tbody>
                  <?php $__currentLoopData = $tabdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                  <tr>
                     <th scope="row"><?php echo $no++;?></th>
                     <td><?php echo e($key->modelno); ?></td>
                     <td><?php echo e($key->name); ?></td>
                     <td><?php $proname=$key->productname; ?><?php echo e(substr($proname,0,30)); ?> </td>
                     <td><?php $sub=$key->shot_description; ?><?php echo e(substr($sub,0,80)); ?> </td>
                     <td><?php $disc=$key->description; ?><?php echo e(substr($disc,0,150)); ?> </td>
                     <td><img style=" max-width: 20vh; max-height: 20vh;" src="uploads/productimage/<?php echo e($key->image); ?>"></td>
                     <td><?php echo e($key->price); ?></td>
                     <td><?php echo e($key->discount); ?></td>
                     <td><?php echo e($key->discount_price); ?></td>
                     <td><?php echo e($key->sell_price); ?></td>
                     <td><?php if($key->status=='active'): ?> <a href="/pro/active/<?php echo e($key->product_id); ?>" class="btn btn-outline-warning">active</a>
                              <?php else: ?> <a href="/pro/active/<?php echo e($key->product_id); ?>" class="btn btn-warning">deactivate</a><?php endif; ?> </td>
                      <td><a href="/PDF/<?php echo e($key->product_id); ?>" class="btn btn-warning">PDF</a></td>
                     <td><a href="/show/pro/<?php echo e($key->product_id); ?>" class="btn btn-primary">Show</a></td>
                     
                    
                     <td><a href="/edit/pro/<?php echo e($key->product_id); ?>" class="btn btn-info">Edit</a></td>
                     <td><a onclick="myFunction(<?php echo $key->product_id ;?>)"  class="btn btn-danger">Delete</a></td>
                  </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                 
            </table>
         </div>
      </div>
   </div>
</div>
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript">
        $(document).ready( function () {
    $('#tbl').DataTable();
} );
    </script>
<script>
   function myFunction($id) {
     var txt;
     var r = confirm("Press a button!");
     if (r == true) {
       window.location.href = "/Delete/pro/"+$id;
     } else {
       txt = "You pressed Cancel!";
     }
     document.getElementById("demo").innerHTML = txt;
   }
</script>           


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/listproduct.blade.php ENDPATH**/ ?>