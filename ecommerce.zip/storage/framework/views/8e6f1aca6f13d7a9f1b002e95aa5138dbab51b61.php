
 <?php $__env->startSection('content'); ?>



<div id="page-wrapper">
   <div class="main-page">
     <?php if($errors->any()): ?>
    <div >
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="  display: block;" class="alert alert-danger"><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
      <div class="forms">
         <h2 class="title1">Forms</h2>
         <div class="form-grids row widget-shadow" data-example-id="basic-forms">
            <div class="form-title">
                     
               <h4>Edit Testi Monials:</h4>
            </div>
            <div class="form-body">
                
               <form method="post">
   <?php echo csrf_field(); ?>
   <input type="hidden" name="id" value="<?php echo e($get[0]->test_id); ?>">
   
                  

                  <div class="form-group"> 
                    <label for="exampleInputPassword1">Title</label> 
                    <input type="text" name="title" class="form-control" id="Category Name" value="<?php echo e($get[0]->title); ?>"  placeholder="Category Name"> 
                </div>
                 
                  <div class="form-group">
                   <label for="exampleInputPassword1">Description</label>
                    <textarea style="border: 2px solid #ccc; width: 100%; min-height: 25vh;" name="description"><?php echo e($get[0]->description); ?></textarea> 
                </div>
                 
                  <button type="submit" class="btn btn-success">Submit</button> 
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\ecommerce\resources\views/edittest.blade.php ENDPATH**/ ?>